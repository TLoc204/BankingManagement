package com.bankingsystem.controller;

import java.time.LocalDate;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.bankingsystem.domain.AccountUser;
import com.bankingsystem.domain.ReceptionBill;
import com.bankingsystem.repository.AccountUserRepository;

@Controller
public class DepositMoneyController {
	
	@Autowired
	private AccountUserRepository accountUserRepository;
	
	@GetMapping("/deposit/{accountNumber}")
	public String deposit(@PathVariable Long accountNumber,Model model) {
		AccountUser ac=accountUserRepository.findByAccountNumber(accountNumber);
		model.addAttribute("detailDeposit", ac);
		
		return "userPages/depositmoney";
	}
	
	@PostMapping("/actionDeposit")
	public String actionDeposit(@ModelAttribute("detailDeposit") AccountUser a) {
		AccountUser ac=accountUserRepository.findByAccountNumber(a.getAccountNumber());
		List<ReceptionBill> listBill=new LinkedList<>();
		ReceptionBill recp=new ReceptionBill();
		
		
		recp.setAction("DEPOSIT");
		recp.setBalance(a.getBalance());
		recp.setStatus("SUCCESSFUL");
		Date nowDate=new Date();
		recp.setTransactionDate(nowDate);
		recp.setSrcAccount("Other");
		recp.setDesAccount(String.valueOf(a.getAccountNumber()));
		
		Long total=ac.getBalance()+a.getBalance();
		ac.setBalance(total);
		recp.setAccountUser(ac);
		listBill.add(recp);
		ac.setReceptionBills(listBill);
		
		accountUserRepository.save(ac);
		
		return "redirect:/deposit/"+a.getAccountNumber();
	}

}
