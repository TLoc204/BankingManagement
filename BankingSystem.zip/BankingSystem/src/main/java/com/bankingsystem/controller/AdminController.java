package com.bankingsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.bankingsystem.domain.Login;
import com.bankingsystem.repository.LoginBankingRepository;

@Controller
public class AdminController {
	@Autowired
	private LoginBankingRepository loginBankingRepository;
	
	
	@GetMapping("/listUser")
	public String listUser(Model model) {
		List<Login> list=loginBankingRepository.findAll();
		list.remove(0);
		model.addAttribute("listUser", list);	
		return "adminPages/adminListUser";
		
	}
	@GetMapping("/delete/{username}")
	public String delete(@PathVariable String username) {
		Login  entity=loginBankingRepository.findByUsername(username);
		loginBankingRepository.delete(entity);
		return "redirect:/listUser";
	}
	
	@GetMapping("/search")
	public String search(@Param("search") String search,Model model) {
		List<Login> list=loginBankingRepository.searchByName(search);
		model.addAttribute("listUser", list);
		return "adminPages/adminListUser";
	}

}
