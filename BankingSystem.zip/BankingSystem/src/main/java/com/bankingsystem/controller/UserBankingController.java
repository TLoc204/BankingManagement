package com.bankingsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.bankingsystem.domain.UserBanking;
import com.bankingsystem.repository.UserBankingRepository;

@Controller
public class UserBankingController {
	
	@Autowired
	private UserBankingRepository userBankingRepository;
	
	@GetMapping("/updateUser/{id}")
	public String updateUser(@PathVariable Long id,Model model) {
		UserBanking ub=userBankingRepository.findByUserId(id);
		model.addAttribute("userBanking", ub);
		return "userPages/userprofile";
	}
	
	@PostMapping("/updateInfor")
	public String saveInfor(@ModelAttribute("userBanking") UserBanking u,Model model) {
		System.out.println(u.getUserid());
		userBankingRepository.save(u);
		UserBanking ub=userBankingRepository.findByUserId(u.getUserid());
		model.addAttribute("userBanking", ub);
		return "redirect:/updateUser/"+u.getUserid();
		
	}

}
