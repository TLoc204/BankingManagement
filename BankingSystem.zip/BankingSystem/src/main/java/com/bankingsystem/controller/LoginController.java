package com.bankingsystem.controller;

import com.bankingsystem.domain.AccountUser;
import com.bankingsystem.domain.Login;
import com.bankingsystem.domain.LoginModel;
import com.bankingsystem.domain.UserBanking;

import java.util.List;
import java.util.Optional;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.bankingsystem.repository.AccountUserRepository;
import com.bankingsystem.repository.LoginBankingRepository;
import com.bankingsystem.repository.UserBankingRepository;

@Controller
public class LoginController {
	
	@Autowired
	private LoginBankingRepository loginBankingRepository;
	
	@Autowired
	private AccountUserRepository accountUserRepository;
	
	@Autowired
	private UserBankingRepository userBankingRepository;


	Login newUser=new Login();
	
//SAVE USER
	@GetMapping("/register")
	public String register(Model model){

		LoginModel l=new LoginModel();
		model.addAttribute("loginModel",l);
		return "loginPage/register";
	}


	@PostMapping("/signup")
	public String save (@ModelAttribute("loginModel") LoginModel loginModel, Model model) {
		try {
			

			newUser.setUsername(loginModel.getUsername());
			newUser.setRole("USER");
			if(loginModel.getPassword().equals(loginModel.getConfirmPassword())){
				String encodePassword = DigestUtils.sha256Hex(loginModel.getPassword());
				newUser.setPassword(encodePassword);
				UserBanking userBanking=new UserBanking();
				model.addAttribute("userBanking", userBanking);
				
				return "loginPage/register_next";
			}else {
				model.addAttribute("msg", "Password not match,Please try again");
				return "redirect:/register";
			}
		}catch (Exception e){
			model.addAttribute("msg","Sign up Unsuccessfully");
			return "redirect:/register";
		}


	}
	
	@PostMapping("/information")
	public String save2(@ModelAttribute("userBanking") UserBanking u) {
		newUser.setUserBanking(u);
		u.setLogin(newUser);
		AccountUser newAccountUser=new AccountUser();
		newAccountUser.setBalance(0L);
		newAccountUser.setStatus("Online");
		newUser.setAccountUser(newAccountUser);
		loginBankingRepository.save(newUser);
		
		return "redirect:/login";
	}
	
	
	
//LOGIN
	
	@GetMapping("/login")
	public String loginPage(Model model) {
		Login login=new Login();
		model.addAttribute("login",login);
		return "loginPage/login";
	}
	

	
	@SuppressWarnings("unused")
	@PostMapping("/doLogin")
	public String checkRole(@ModelAttribute("login") Login login,Model model) {
		Login check=loginBankingRepository.findByUsername(login.getUsername());
		
		
		String encodePassword=DigestUtils.sha256Hex(login.getPassword());
		
		if(check==null) {
			model.addAttribute("msg","Account not exist");
			return "redirect:/login";
		}
		if(check.getPassword().equals(encodePassword)) {
			if (check.getRole().equals("ADMIN")) {
				return "adminPages/adminDashboard";
			}
			if (check.getRole().equals("USER")) {
					AccountUser au=accountUserRepository.findByAccountNumber(check.getAccountUser().getAccountNumber());
					UserBanking ub=userBankingRepository.findByUserId(check.getUserBanking().getUserid());
				
					model.addAttribute("accountUser",au);
					model.addAttribute("userBanking",ub);
					return "userPages/userDashboard";

			}
			
		}
		
		return "redirect:/login";
	}

}
