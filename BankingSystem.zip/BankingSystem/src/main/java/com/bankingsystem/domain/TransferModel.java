package com.bankingsystem.domain;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class TransferModel {
	private String srcAccount;
	private String desAccount;
	private Long amount;
}
