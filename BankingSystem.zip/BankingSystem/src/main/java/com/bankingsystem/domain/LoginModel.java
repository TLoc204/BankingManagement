package com.bankingsystem.domain;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Data
public class LoginModel {
	private String username;
	private String password;
	private String confirmPassword;

}
