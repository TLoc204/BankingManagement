package com.bankingsystem.domain;

import lombok.*;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity
@Table(name = "userbanking")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserBanking {
    @Id
    @GeneratedValue
    private Long userid;
    @Column(name = "fullname")
    private String fullname;
    @Column(name = "birthday")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthday;
    @Column(name = "address")
    private String address;
    @Column(name = "nationalid")
    private Long nationalId;
    @Column(name = "phone")
    private int phoneNo;
    @Column(name = "email")
    private String email;

    @OneToOne(mappedBy = "userBanking")
    private Login login;


	
    
    
    


    

}
