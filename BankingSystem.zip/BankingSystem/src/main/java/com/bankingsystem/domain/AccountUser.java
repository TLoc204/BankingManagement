package com.bankingsystem.domain;

import lombok.*;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "accountuser")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountUser {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="accountnumber")
    private Long accountNumber;
    private Long balance;
    private String status;

    @OneToMany(cascade = CascadeType.ALL,mappedBy = "accountUser")
    private List<ReceptionBill> receptionBills;

    @OneToOne(cascade = CascadeType.ALL, mappedBy = "accountUser")
    private Login login;



	
    
    

}
